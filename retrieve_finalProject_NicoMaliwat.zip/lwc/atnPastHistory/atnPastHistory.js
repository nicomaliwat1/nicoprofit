import { LightningElement,track,api,wire } from 'lwc';
import pastEvent from '@salesforce/apex/AttendeeHistoryController.pastEvent';

export default class AtnPastHistory extends LightningElement {
    @track columns = [
        {
            label: 'Event Name',
            fieldName: 'Event_Name__c',
            type: 'text',
            sortable: true
        },
        {
            label: 'Location',
            fieldName: 'Location',
            type: 'text',
            sortable: true
        },
        {
            label: 'Organizer',
            fieldName: 'Organizer',
            type: 'text',
            sortable: true
        },
        {
            label: 'Start Date and Time',
            fieldName: 'Start_Date_and_Time__c',
            type: "date",
            typeAttributes: {
              weekday: "long",
              year: "numeric",
              day: "numeric",
              month: "long"
            }
        }
        
        ];
    @api atnid;
    @track eventDet=[];
    @wire (pastEvent,{atnId: '$atnid'}) wiredAtnId({error,data}){
        var returnOptions = [];
        console.log(data);
        if(data){   
            data.forEach(ele => {
                var loc;
                var org;
                if(ele.Location__r){
                    loc = ele.Location__r.Name;
                }else{
                    loc = 'This is Virtual';
                }
                if(ele.Event_Organizer__r){
                    org = ele.Event_Organizer__r.Name;
                }else{
                    org = 'N/A';
                }
                returnOptions.push({Event_Name__c:ele.Event_Name__c,Start_Date_and_Time__c:ele.Start_Date_and_Time__c,Location:loc,Organizer:org});  
            });
            this.eventDet = returnOptions;
            console.log(eventDet);
        }
    }
}