import { LightningElement,track,api,wire } from 'lwc';
import eventSpkIdRet from '@salesforce/apex/EventSpeakerRetrieval.eventSpkIdRet';

export default class EventSpeakerDet extends LightningElement {
    @track columns = [
        {
            label: 'Attendee Name',
            fieldName: 'Name',
            type: 'text',
            sortable: true
        },
        {
            label: 'Phone Number',
            fieldName: 'Phone__c',
            type: 'phone',
            sortable: true
        },
        {
            label: 'Email',
            fieldName: 'Email__c',
            type: 'text',
            sortable: true
        },
        {
            label: 'Company',
            fieldName: 'Company__c',
            type: 'text',
            sortable: true
        },
        {
            label: 'Location',
            fieldName: 'Location__c',
            type: 'text',
            sortable: true
        }
        
        ];
        @api eventid;
        @track spkDet;
        @wire (eventSpkIdRet,{evtId: '$eventid'}) wiredAtnId({error,data}){
            if(data){
                console.log(JSON.stringify(data));
                this.spkDet = data;
            }
        }

}