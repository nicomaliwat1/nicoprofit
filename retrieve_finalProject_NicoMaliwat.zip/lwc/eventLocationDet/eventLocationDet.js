import { LightningElement,track,api,wire } from 'lwc';
import locRet from '@salesforce/apex/EventRetrieval.locRet';

export default class EventLocationDet extends LightningElement {
    @api eventid;
    @track locId;
    @wire (locRet,{evtId: '$eventid'})  locIdRet({err,data}){
        if(data){
            console.log(data.Location__c);
            this.locId = data.Location__c;
        }
    };

    
   
}