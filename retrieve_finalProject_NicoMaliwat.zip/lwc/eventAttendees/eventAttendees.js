import { LightningElement,api,wire,track } from 'lwc';
import atndRet from '@salesforce/apex/AttendeeRetrieval.atndRet';

export default class EventAttendees extends LightningElement {
    @track columns = [
    {
        label: 'Attendee Name',
        fieldName: 'Name',
        type: 'text',
        sortable: true
    },
    {
        label: 'Phone Number',
        fieldName: 'Phone__c',
        type: 'phone',
        sortable: true
    },
    {
        label: 'Email',
        fieldName: 'Email__c',
        type: 'text',
        sortable: true
    },
    {
        label: 'Company',
        fieldName: 'Company__c',
        type: 'text',
        sortable: true
    },
    {
        label: 'Location',
        fieldName: 'Location__c',
        type: 'text',
        sortable: true
    }
    
    ];
    @api eventid;
    @track atnDet;
    @wire (atndRet,{evtId: '$eventid'}) wiredAtnId({error,data}){
        if(data){
            this.atnDet = data;
        }
    }
}