import { LightningElement,track,wire,api } from 'lwc';

export default class EventDetail extends LightningElement {
    @api recordId;

}