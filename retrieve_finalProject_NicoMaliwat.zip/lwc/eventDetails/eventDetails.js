import { LightningElement,track,api, wire } from 'lwc';


export default class EventDetails extends LightningElement {
    @api eventid;

}