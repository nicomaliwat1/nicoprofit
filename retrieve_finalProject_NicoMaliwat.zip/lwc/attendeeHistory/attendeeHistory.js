import { LightningElement,api } from 'lwc';

export default class AttendeeHistory extends LightningElement {
    @api recordId;
}